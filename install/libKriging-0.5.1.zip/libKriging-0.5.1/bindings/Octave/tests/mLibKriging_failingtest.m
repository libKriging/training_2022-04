% clear all
mLibKriging("bad command")