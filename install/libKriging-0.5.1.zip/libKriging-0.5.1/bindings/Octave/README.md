

mexErrMsgIdAndTxt("mLibKriging:NoRoute", "No route to such command [%s]", command);
```
> [errormsg, msg_id] = lasterr
errormsg = mLibKriging: No route to such command [AAA]
msg_id = mLibKriging:NoRoute
```

msg_id should be a unique identifier for error