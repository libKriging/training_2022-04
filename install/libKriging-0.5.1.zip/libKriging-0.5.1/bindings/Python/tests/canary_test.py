
def test_canary():
    print("Trivial test to check environment")