import pylibkriging as m
import pytest


def test_version():
    assert m.__version__ == '0.5.1'
