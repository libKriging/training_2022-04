This page contains useful links to Travis CI features.

The full documentation is available on [Travis CI documentation](https://docs.travis-ci.com).

# Validate .travis.yml before pushing

Project https://github.com/haveneer/travis-ci-yml contains a TravisCI linter command.

# Use Docker in Travis CI

* https://docs.travis-ci.com/user/docker/

# Add Worker to Travis CI

* https://github.com/travis-ci/worker