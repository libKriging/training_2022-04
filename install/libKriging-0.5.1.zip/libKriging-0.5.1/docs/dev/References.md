
* [Armadillo documentation](http://arma.sourceforge.net/docs.html)
* [Catch2 documentation](https://github.com/catchorg/Catch2/blob/master/docs/Readme.md)
* [Doxygen](http://www.doxygen.nl/manual/index.html)