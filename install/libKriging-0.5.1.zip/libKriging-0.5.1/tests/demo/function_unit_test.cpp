#include <iostream>
#include <memory>

#include "libKriging/demo/DemoFunction.hpp"

int main() {
  std::cout << "libKriging function tests" << std::endl;

  std::cout << f() << std::endl;

  return 0;
}