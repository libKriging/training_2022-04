#include "libKriging/demo/DemoFunction.hpp"

LIBKRIGING_EXPORT int f() {
  // NOLINTNEXTLINE(cppcoreguidelines-avoid-magic-numbers,readability-magic-numbers)
  return 42;
}