#ifndef LIBKRIGING_DEMO_HPP
#define LIBKRIGING_DEMO_HPP

/** @defgroup Demo for demo purpose only */
#include "demo/DemoArmadilloClass.hpp"
#include "demo/DemoClass.hpp"
#include "demo/DemoFunction.hpp"

#endif  // LIBKRIGING_DEMO_HPP
