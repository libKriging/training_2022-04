#ifndef LIBKRIGING_DEMOFUNCTION_HPP
#define LIBKRIGING_DEMOFUNCTION_HPP

#include "libKriging/libKriging_exports.h"

/** This is a demo class about about function usage
 *  @ingroup Demo Demo group
 *  \deprecated Demo only
 */
LIBKRIGING_EXPORT int f();

#endif  // LIBKRIGING_DEMOFUNCTION_HPP
